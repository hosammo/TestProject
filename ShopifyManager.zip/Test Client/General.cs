﻿using Shopify.IO;
using Shopify_Manager.SettingsTypes;
using System;

namespace Shopify_Manager
{
    public static class General
    {
        public static Settings SettingsObj;

        public static Profile CurrentProfile;




        //connection to sql

        //public static void openConnection()
        //{
        //    DbConnection.ConnectionString = Properties.Settings.Default.OceanDB;
        //    DbConnection.Open();
        //}

        //public static int GetBarcodeQty(string barcode, string sourceDatabase = "")
        //{
        //    if (General.DbConnection.State != System.Data.ConnectionState.Open)
        //        openConnection();

        //    if (General.cm == null)
        //        General.cm = General.DbConnection.CreateCommand();

        //    General.cm.CommandText = "Select Qty from " + sourceDatabase + ".dbo.QtyByVariant where barcode = '" + barcode + "'";

        //    var tmpqty = General.cm.ExecuteScalar();

        //    try
        //    {
        //        return (int)tmpqty;
        //    }
        //    catch (Exception)
        //    {
        //        return -1;
        //    }
        //}

        //public static decimal GetVariantPrice(string barcode, string sourceDatabase = "")
        //{
        //    if (General.DbConnection.State != System.Data.ConnectionState.Open)
        //        openConnection();

        //    if (General.cm == null)
        //        General.cm = General.DbConnection.CreateCommand();

        //    General.cm.CommandText = "SELECT  CASE WHEN Sale = 0 THEN Price ELSE Sale END AS Price FROM " + sourceDatabase + ".shopify.VariantPrices where barcode = '" + barcode + "'";

        //    var tmpqty = General.cm.ExecuteScalar();

        //    try
        //    {
        //        if (tmpqty != null)
        //            return Convert.ToDecimal(tmpqty);
        //        else
        //            return -1;
        //    }
        //    catch (Exception)
        //    {
        //        return -1;
        //    }
        //}

        //public static decimal GetVariantComparedAtPrice(string barcode, string sourceDatabase = "")
        //{
        //    if (General.DbConnection.State != System.Data.ConnectionState.Open)
        //        openConnection();

        //    if (General.cm == null)
        //        General.cm = General.DbConnection.CreateCommand();

        //    General.cm.CommandText = "SELECT CASE WHEN Sale <> 0 THEN Price ELSE 0 END AS compare_at_price  FROM " + sourceDatabase + ".shopify.VariantPrices where barcode = '" + barcode + "'";

        //    var tmpqty = General.cm.ExecuteScalar();

        //    try
        //    {
        //        return Convert.ToDecimal(tmpqty);
        //    }
        //    catch (Exception)
        //    {
        //        return -1;
        //    }
        //}

        //public static decimal GetProductPrice(string ComputerNo, string sourceDatabase = "")
        //{
        //    if (General.DbConnection.State != System.Data.ConnectionState.Open)
        //        openConnection();

        //    if (General.cm == null)
        //        General.cm = General.DbConnection.CreateCommand();

        //    General.cm.CommandText = "SELECT TOP 1 CASE WHEN Sale = 0 THEN Price ELSE Sale END AS Price FROM " + sourceDatabase + ".shopify.VariantPrices where ComputerNo = '" + ComputerNo + "'";

        //    var tmpqty = General.cm.ExecuteScalar();

        //    try
        //    {
        //        if (tmpqty != null)
        //            return Convert.ToDecimal(tmpqty);
        //        else
        //            return -1;
        //    }
        //    catch (Exception)
        //    {
        //        return -1;
        //    }
        //}

        //public static Decimal GetProductComparedAtPrice(string ComputerNo, string sourceDatabase = "")
        //{
        //    if (General.DbConnection.State != System.Data.ConnectionState.Open)
        //        openConnection();

        //    if (General.cm == null)
        //        General.cm = General.DbConnection.CreateCommand();

        //    General.cm.CommandText = "SELECT TOP 1 CASE WHEN Sale <> 0 THEN Price ELSE 0 END AS compare_at_price  FROM " + sourceDatabase + ".shopify.VariantPrices where ComputerNo = '" + ComputerNo + "'";

        //    var tmpqty = General.cm.ExecuteScalar();

        //    try
        //    {
        //        return Convert.ToDecimal(tmpqty);
        //    }
        //    catch (Exception)
        //    {
        //        return -1;
        //    }
        //}

        //public static DataTable ExecuteDatatable(string sqlCommand)
        //{
        //    if (General.DbConnection.State != System.Data.ConnectionState.Open)
        //        openConnection();

        //    if (General.cm == null)
        //        General.cm = General.DbConnection.CreateCommand();

        //    SqlCommand OceanCM = General.DbConnection.CreateCommand();
        //    DataTable dt = new DataTable();
        //    using (OceanCM)
        //    {
        //        OceanCM.CommandText = sqlCommand;

        //        SqlDataAdapter sda = new SqlDataAdapter(OceanCM);


        //        sda.Fill(dt);
        //    }
        //    return dt;

        //}

        //public static DataSet ExecuteDataSet(string sqlCommand)
        //{
        //    if (General.DbConnection.State != System.Data.ConnectionState.Open)
        //        openConnection();

        //    if (General.cm == null)
        //        General.cm = General.DbConnection.CreateCommand();

        //    SqlCommand OceanCM = General.DbConnection.CreateCommand();
        //    DataSet ds = new DataSet();
        //    using (OceanCM)
        //    {

        //        OceanCM.CommandText = sqlCommand;

        //        SqlDataAdapter sda = new SqlDataAdapter(OceanCM);

        //        sda.Fill(ds);

        //    }
        //    return ds;

        //}

    }
}
