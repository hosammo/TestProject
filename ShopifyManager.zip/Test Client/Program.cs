﻿using Shopify_Manager.ErrorLogging;
using Shopify_Manager.UI;
using System;
using System.Threading;
using System.Windows.Forms;

namespace Shopify_Manager
{
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);

            // Global exception handlers
            Application.ThreadException += new ThreadExceptionEventHandler(Application_ThreadException);
            AppDomain.CurrentDomain.UnhandledException += new UnhandledExceptionEventHandler(CurrentDomain_UnhandledException);


#if DEBUG
            Application.Run(new Main_frm());
#else
            Main_frm n = new Main_frm();
            n.ShowInTaskbar = true;
            Application.Run(n); 
#endif
        }

        private static void Application_ThreadException(object sender, ThreadExceptionEventArgs e)
        {
            ErrorLogger.Log(e.Exception);
            MessageBox.Show("An unexpected error occurred (UI). Check the error log.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }

        private static void CurrentDomain_UnhandledException(object sender, UnhandledExceptionEventArgs e)
        {
            if (e.ExceptionObject is Exception ex)
            {
                ErrorLogger.Log(ex);
                MessageBox.Show("An unexpected error occurred (background). Check the error log.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

    }
}
