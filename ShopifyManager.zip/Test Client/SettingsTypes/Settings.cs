﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;

namespace Shopify_Manager.SettingsTypes
{
    public class Profile
    {
        public string ProfileName { get; set; }
        public string ApiKey { get; set; }
        public string Password { get; set; }
        public string SharedSecret { get; set; }
        public string HostName { get; set; }
        public string OceanDB { get; set; }
        public string CachingDB { get; set; }
        public string ApiVersion { get; set; }
        public string Currency { get; set; }

    }

    public class Settings
    {
        public void LoadSettings()
        {
            string settingsJson;
            // Read the file and display it line by line.
            System.IO.StreamReader file = new System.IO.StreamReader(System.IO.Path.GetDirectoryName(System.Reflection.Assembly.GetExecutingAssembly().Location) + "\\Settings.ini");
            settingsJson = file.ReadToEnd();
            file.Close();

            SettingsRootObject obj = JsonConvert.DeserializeObject<SettingsRootObject>(settingsJson);

            Profiles = obj.Settings.Profiles;
        }

        public List<Profile> Profiles { get; set; }

    }

    class SettingsRootObject
    {
        public Settings Settings { get; set; }
    }
}
